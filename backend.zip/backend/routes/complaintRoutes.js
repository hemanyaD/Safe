import express from "express";

import {
  createReport,
  getAllComplaints,
  getComplaintById,
  updateComplaintStatus
} from "../controllers/complaintController.js";
import { evidenceUpload } from "../middleware/uploadEvidence.js";

const router = express.Router();

// Allow both JSON requests and multipart/form-data (with file uploads).
function maybeEvidenceUpload(req, res, next) {
  if (req.is("multipart/form-data")) return evidenceUpload(req, res, next);
  return next();
}

router.post("/report", maybeEvidenceUpload, createReport);
router.get("/complaints", getAllComplaints);
router.get("/complaints/:id", getComplaintById);
router.put("/complaints/:id/status", updateComplaintStatus);

export default router;

