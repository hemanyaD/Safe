import express from "express";
import { getSafetyScore } from "../controllers/safetyController.js";

const router = express.Router();

router.get("/safety-score", getSafetyScore);

export default router;

