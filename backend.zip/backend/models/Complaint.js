import mongoose from "mongoose";

const STATUS = ["Submitted", "Under Review", "Action Taken", "Closed"];

const ComplaintSchema = new mongoose.Schema(
  {
    id: { type: String, required: true, unique: true, index: true },
    description: { type: String, required: true, trim: true },
    location: { type: String, required: true, trim: true },
    evidence: { type: [String], default: [] },
    status: { type: String, enum: STATUS, default: "Submitted" },
    timestamp: { type: Date, default: Date.now }
  },
  { versionKey: false }
);

export const COMPLAINT_STATUSES = STATUS;
export default mongoose.model("Complaint", ComplaintSchema);

