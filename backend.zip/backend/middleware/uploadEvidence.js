import multer from "multer";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const backendDir = path.dirname(__dirname);
const uploadDirName = process.env.UPLOAD_DIR || "uploads";
const uploadDir = path.join(backendDir, uploadDirName);

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

function safeFileName(originalName) {
  return originalName
    .replace(/[^a-zA-Z0-9._-]/g, "_")
    .slice(0, 120);
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || "";
    const base = path.basename(file.originalname, ext) || "evidence";
    cb(null, `${Date.now()}-${safeFileName(base)}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB per file
  },
  fileFilter: (_req, file, cb) => {
    // Keep it simple for hackathons: accept most common evidence types.
    const allowed =
      file.mimetype.startsWith("image/") ||
      file.mimetype.startsWith("video/") ||
      file.mimetype === "application/pdf";
    cb(null, allowed);
  }
});

// Field name: evidenceFiles
export const evidenceUpload = upload.array("evidenceFiles", 5);

