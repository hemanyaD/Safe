import express from "express";
import cors from "cors";
import morgan from "morgan";
import path from "path";
import { fileURLToPath } from "url";

import complaintRoutes from "./routes/complaintRoutes.js";
import safetyRoutes from "./routes/safetyRoutes.js";
import notFound from "./middleware/notFound.js";
import errorHandler from "./middleware/errorHandler.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

const uploadDirName = process.env.UPLOAD_DIR || "uploads";
const uploadDir = path.join(__dirname, uploadDirName);

// Middlewares
app.use(morgan("dev"));

app.use(
  cors({
    origin:
      !process.env.CORS_ORIGIN || process.env.CORS_ORIGIN === "*"
        ? true
        : process.env.CORS_ORIGIN.split(",").map((s) => s.trim()),
    credentials: false,
  })
);

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// Serve uploaded evidence locally
app.use("/uploads", express.static(uploadDir));

app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

app.use("/", complaintRoutes);
app.use("/", safetyRoutes);

app.use(notFound);
app.use(errorHandler);

export default app;

