import dotenv from "dotenv";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import app from "./app.js";
import connectDB from "./config/db.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const port = Number(process.env.PORT || 4000);
const uploadDirName = process.env.UPLOAD_DIR || "uploads";
const uploadDir = path.join(__dirname, uploadDirName);

// Ensure upload directory exists (multer + static hosting).
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

async function start() {
  await connectDB();

  const server = app.listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`[server] Listening on http://localhost:${port}`);
  });

  // Graceful shutdown.
  const shutdown = async (signal) => {
    // eslint-disable-next-line no-console
    console.log(`[server] Received ${signal}, shutting down...`);
    server.close(() => process.exit(0));
  };

  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

start().catch((err) => {
  // eslint-disable-next-line no-console
  console.error("[server] Failed to start:", err);
  process.exit(1);
});

