function parseLatLngFromString(str) {
  if (typeof str !== "string") return null;
  const parts = str
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  if (parts.length !== 2) return null;
  const lat = Number(parts[0]);
  const lng = Number(parts[1]);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  return { lat, lng };
}

function parseLatLng(input) {
  if (!input) return null;

  if (typeof input === "string") {
    return parseLatLngFromString(input);
  }

  if (Array.isArray(input) && input.length === 2) {
    const lat = Number(input[0]);
    const lng = Number(input[1]);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    return { lat, lng };
  }

  if (typeof input === "object") {
    const lat = Number(input.lat ?? input.latitude);
    const lng = Number(input.lng ?? input.longitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    return { lat, lng };
  }

  return null;
}

export function normalizeLocation(input) {
  const coords = parseLatLng(input);
  if (coords) {
    return `${coords.lat},${coords.lng}`;
  }

  if (typeof input === "string") {
    const trimmed = input.trim();
    if (!trimmed) throw new Error("location cannot be empty");
    return trimmed;
  }

  if (input && typeof input === "object") {
    // Unsupported object shape for location.
    throw new Error("location must be a string or coordinates");
  }

  throw new Error("location must be a string or coordinates");
}

export function computeAreaKey(locationStr) {
  const coords = parseLatLngFromString(locationStr);
  if (coords) {
    const latR = Math.round(coords.lat * 100) / 100;
    const lngR = Math.round(coords.lng * 100) / 100;
    return `${latR},${lngR}`;
  }

  // For text locations, use the first segment as a crude "area".
  // Example: "Downtown, City" -> "Downtown"
  if (typeof locationStr === "string") {
    return locationStr.split(",")[0].trim().toLowerCase();
  }

  return "";
}

