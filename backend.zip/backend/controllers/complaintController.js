import { randomUUID } from "crypto";
import Complaint, { COMPLAINT_STATUSES } from "../models/Complaint.js";
import asyncHandler from "../middleware/asyncHandler.js";
import { normalizeLocation } from "../utils/location.js";

function parseEvidenceInput(evidence) {
  if (evidence === undefined || evidence === null) return [];
  if (Array.isArray(evidence)) return evidence.filter((v) => typeof v === "string");
  if (typeof evidence === "string") {
    const trimmed = evidence.trim();
    if (!trimmed) return [];
    if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
      try {
        const parsed = JSON.parse(trimmed);
        if (Array.isArray(parsed)) {
          return parsed.filter((v) => typeof v === "string");
        }
      } catch {
        // Fall through to treating it as a single evidence value.
      }
    }
    return [trimmed];
  }
  return [];
}

function parseBoolean(input) {
  if (typeof input === "boolean") return input;
  if (typeof input === "string") {
    if (input.toLowerCase() === "true") return true;
    if (input.toLowerCase() === "false") return false;
  }
  return false;
}

function getEvidenceBaseUrl() {
  if (process.env.EVIDENCE_BASE_URL) return process.env.EVIDENCE_BASE_URL;
  const port = process.env.PORT || 4000;
  return `http://localhost:${port}`;
}

export const createReport = asyncHandler(async (req, res) => {
  const { description, location, evidence, anonymous } = req.body;

  if (typeof description !== "string" || !description.trim()) {
    return res.status(400).json({ error: "description is required" });
  }
  if (!location) {
    return res.status(400).json({ error: "location is required" });
  }

  let normalizedLocation;
  try {
    normalizedLocation = normalizeLocation(location);
  } catch (err) {
    return res.status(400).json({ error: err.message || "Invalid location" });
  }

  // Evidence can come from JSON body (array of URLs/base64 strings) and/or file uploads.
  const evidenceList = parseEvidenceInput(evidence);

  const evidenceBaseUrl = getEvidenceBaseUrl();
  const uploadedFiles = req.files || [];
  const uploadedEvidence = uploadedFiles.map((file) => {
    return `${evidenceBaseUrl}/uploads/${file.filename}`;
  });

  const combinedEvidence = [...evidenceList, ...uploadedEvidence];

  // For hackathon simplicity, we accept the "anonymous" flag but don't store any reporter info.
  // Still parse it to show the API supports it.
  const isAnonymous = parseBoolean(anonymous);
  void isAnonymous;

  const id = randomUUID();

  const complaint = await Complaint.create({
    id,
    description: description.trim(),
    location: normalizedLocation,
    evidence: combinedEvidence,
    status: "Submitted",
    timestamp: new Date()
  });

  return res.status(201).json({
    id: complaint.id,
    status: complaint.status,
    timestamp: complaint.timestamp,
    // Evidence URLs may be local paths under /uploads.
    evidenceBaseUrl
  });
});

export const getAllComplaints = asyncHandler(async (_req, res) => {
  const complaints = await Complaint.find({}).sort({ timestamp: -1 });
  res.json({ complaints });
});

export const getComplaintById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const complaint = await Complaint.findOne({ id });
  if (!complaint) {
    return res.status(404).json({ error: "Complaint not found" });
  }

  res.json({ complaint });
});

export const updateComplaintStatus = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!status || typeof status !== "string") {
    return res.status(400).json({ error: "status is required" });
  }
  const normalizedStatus = status.trim();

  if (!COMPLAINT_STATUSES.includes(normalizedStatus)) {
    return res.status(400).json({ error: `Invalid status. Allowed: ${COMPLAINT_STATUSES.join(", ")}` });
  }

  const complaint = await Complaint.findOne({ id });
  if (!complaint) {
    return res.status(404).json({ error: "Complaint not found" });
  }

  const transition = {
    "Submitted": "Under Review",
    "Under Review": "Action Taken",
    "Action Taken": "Closed"
  };

  const expectedNext = transition[complaint.status];
  if (expectedNext !== normalizedStatus) {
    return res.status(400).json({
      error: `Invalid transition. Current: ${complaint.status}. Next must be: ${expectedNext}`
    });
  }

  complaint.status = normalizedStatus;
  await complaint.save();

  res.json({ complaint });
});

