import asyncHandler from "../middleware/asyncHandler.js";
import Complaint from "../models/Complaint.js";
import { computeAreaKey, normalizeLocation } from "../utils/location.js";

function computeScore(incidents) {
  // Simple hackathon rule:
  // 0 incidents => 100
  // 1 incident  => 80
  // 2 incidents => 60
  // 3 incidents => 40
  // 4+ incidents=> 20..0
  const score = 100 - incidents * 20;
  return Math.max(0, Math.min(100, score));
}

export const getSafetyScore = asyncHandler(async (req, res) => {
  const { location } = req.query;
  if (!location || typeof location !== "string" || !location.trim()) {
    return res.status(400).json({ error: "location query parameter is required" });
  }

  let normalizedLocation;
  try {
    normalizedLocation = normalizeLocation(location);
  } catch (err) {
    return res.status(400).json({ error: err.message || "Invalid location" });
  }
  const areaKey = computeAreaKey(normalizedLocation);
  if (!areaKey) {
    return res.status(400).json({ error: "Invalid location format" });
  }

  // For beginner-friendly simplicity, fetch all complaints and compute.
  // (Good enough for a small hackathon dataset.)
  const complaints = await Complaint.find({}, { location: 1 });

  const incidents = complaints.reduce((count, c) => {
    const cAreaKey = computeAreaKey(c.location);
    return cAreaKey === areaKey ? count + 1 : count;
  }, 0);

  const score = computeScore(incidents);

  res.json({
    location: normalizedLocation,
    areaKey,
    incidents,
    score
  });
});

