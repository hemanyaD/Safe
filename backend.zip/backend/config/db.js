import mongoose from "mongoose";

export default async function connectDB() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("Missing MONGODB_URI in environment.");
  }

  // Mongoose will reuse an existing connection if present.
  await mongoose.connect(uri, {
    // Keep defaults; Mongoose manages most options internally.
  });

  // eslint-disable-next-line no-console
  console.log("[db] Connected to MongoDB");
}

